# -*- coding: utf-8 -*-
"""
run_experiments.py — Paper 3 main experiment runner.

Explains N_SAMPLES test (gene, phenotype) pairs + a flowering-module cohort
with ReGEX and four baselines on three base models (GraphSAGE / RGCN / HGT),
and evaluates every explanation with the FSC framework.

Usage:
    python run_experiments.py --smoke      # quick correctness check (20 pairs)
    python run_experiments.py              # full run (N_SAMPLES pairs)
"""
import os, sys, json, argparse, re, time
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C
from explainers import (build_subgraph, restore_model, reg_explain,
                        mask_only_explain, saliency_edge, ig_edge, random_edge)
from evaluate import evaluate_pair
from paths import extract_paths, path_biology
from sklearn.metrics import roc_auc_score

FLOWER_RE = re.compile(C.FLOWER_PHENO_RE, re.I)
CURATED = {"AT5G10140", "AT1G65480", "AT2G45660"}


def load_evidence_map(gene_list):
    m = pd.read_csv(os.path.join(C.P2_CURATED_DIR, "15_gene_evidence_matrix.csv"))
    m["Gene"] = m["Gene"].map(lambda s: str(s).strip().upper())
    # continuous per-gene omics evidence: total supported-association count
    cols = [c for c in m.columns
            if c.startswith(("n_cis", "n_trans", "n_emqtl", "n_twas", "n_gwas"))]
    ev = m.set_index("Gene")[cols].sum(axis=1)
    return {i: float(ev.get(g, 0.0)) for i, g in enumerate(gene_list)}


def load_flowering(gene_list):
    flow = pd.read_csv(os.path.join(C.P2_CURATED_DIR, "16_flowering_candidates.csv"))
    names = set(flow["Gene"].astype(str).str.strip().str.upper()) | \
            {"AT5G10140", "AT1G65480", "AT2G45660"}
    return np.array([i for i, g in enumerate(gene_list)
                     if g in names], dtype=np.int64)


def sample_targets(splits, pheno_list, n, rng):
    test_pos = splits["test_pos"]  # [2, n]
    cold = set(splits["cold_phenotypes"])
    idx = [i for i in range(test_pos.shape[1])
           if test_pos[1, i] not in cold]
    pick = rng.choice(idx, min(n, len(idx)), replace=False)
    return test_pos[:, pick]


FRACS = [0.05, 0.10, 0.20, 0.50]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--models", nargs="*", default=["sage", "rgcn", "hgt"])
    ap.add_argument("--methods", nargs="*",
                    default=["regex", "maskonly", "saliency", "ig", "random"])
    args = ap.parse_args()

    data = C.load_data()
    splits = C.load_splits()
    nn = json.load(open(os.path.join(C.P2_DATA_DIR, "node_names.json"), encoding="utf-8"))
    gene_list, pheno_list = nn["gene"], nn["phenotype"]
    evidence = load_evidence_map(gene_list)
    flower_idx = load_flowering(gene_list)
    pheno_map = {p: i for i, p in enumerate(pheno_list)}
    flow_pheno = [pheno_map[p] for p in pheno_list if FLOWER_RE.search(p)]

    rng = np.random.default_rng(7)
    n_pairs = 20 if args.smoke else C.N_SAMPLES
    test_pairs = sample_targets(splits, pheno_list, n_pairs, rng)
    # flowering cohort: first 30 curated flowering genes x first 5 flow phenos
    n_flow_g = 5 if args.smoke else 30
    n_flow_p = 2 if args.smoke else 5
    flow_genes = [int(i) for i in flower_idx[:n_flow_g] if int(i) < len(gene_list)]
    flow_pairs = np.array([(g, p) for g in flow_genes for p in flow_pheno[:n_flow_p]],
                          dtype=np.int64).T  # [2, n]
    if flow_pairs.shape[1] == 0:
        flow_pairs = np.zeros((2, 0), dtype=np.int64)
    all_pairs = np.concatenate([test_pairs, flow_pairs], axis=1)
    pair_kind = ["test"] * test_pairs.shape[1] + ["flower"] * flow_pairs.shape[1]
    print(f"explaining {all_pairs.shape[1]} pairs "
          f"({test_pairs.shape[1]} test, {flow_pairs.shape[1]} flowering) "
          f"on {len(args.models)} models x {len(args.methods)} methods",
          flush=True)

    rows = []
    path_rows = []
    bio_rows = []
    for mname in args.models:
        ck = torch.load(os.path.join(C.P2_MODELS_DIR, f"{mname}_s{C.SEED}.pt"),
                        map_location="cpu", weights_only=False)
        model = restore_model(mname, data, ck)
        t0 = time.time()
        for k in range(all_pairs.shape[1]):
            g, p = int(all_pairs[0, k]), int(all_pairs[1, k])
            sub, keep, local, _ = build_subgraph(data, g, p)
            g_l = local["gene"][g]
            p_l = local["phenotype"][p]
            ev_map = {}
            for (t, idx) in keep:
                if t == "gene":
                    ev_map[idx] = evidence.get(idx, 0.0)
            ig_w = None
            method_weights = {}
            for meth in args.methods:
                if meth == "regex":
                    w, s0 = reg_explain(model, data, sub, local, g, p, g_l, p_l)
                elif meth == "maskonly":
                    w, s0 = mask_only_explain(model, data, sub, g, p, g_l, p_l)
                elif meth == "saliency":
                    w, s0 = saliency_edge(model, data, sub, g, p, g_l, p_l)
                elif meth == "ig":
                    w, s0 = ig_edge(model, data, sub, g, p, g_l, p_l)
                    ig_w = w
                elif meth == "random":
                    w, s0 = random_edge(sub)
                else:
                    raise ValueError(meth)
                method_weights[meth] = w
            # evaluate each method across sparsity budgets against IG reference
            ref_ig = method_weights.get("ig")
            for meth in args.methods:
                w = method_weights[meth]
                for frac in FRACS:
                    r = evaluate_pair(model, sub, w, g_l, p_l, ev_map, ref_ig,
                                      frac=frac, data=data, local=local)
                    rows.append({"model": mname, "pair_kind": pair_kind[k],
                                 "gene_idx": g, "pheno_idx": p, "method": meth,
                                 "frac": frac,
                                 "fidelity_plus": r["fidelity_plus"],
                                 "fidelity_minus": r["fidelity_minus"],
                                 "sparsity": r["sparsity"], "egc": r["egc"],
                                 "rank_ig": r["rank_ig"],
                                 "n_selected": r["n_selected"],
                                 "n_total": r["n_total"],
                                 "s_full": r["s_full"]})
            # path extraction on the ReGEX explanation for every pair
            w = method_weights["regex"]
            tg = [(t, idx) for (t, idx) in keep if t == "phenotype" and idx == p]
            tg += [("gene", gi) for gi in flower_idx if gi in local["gene"]]
            if not tg:
                tg = [("phenotype", p)]
            paths, f2g = extract_paths(sub, w, local, g, tg, gene_list, pheno_list,
                                       top_k=C.TOP_PATHS)
            for rank_i, pt in enumerate(paths):
                nstr = ";".join(f"{nt}:{gidx}" for (nt, gidx) in pt["nodes_global"])
                rstr = ";".join(pt["relations"])
                path_rows.append({"model": mname, "pair_kind": pair_kind[k],
                                  "gene_idx": g, "pheno_idx": p,
                                  "rank": rank_i + 1, "score": pt["score"],
                                  "length": pt["length"],
                                  "reached_target": pt["reached_target"],
                                  "nodes_global": nstr, "relations": rstr})
            bio = path_biology(paths, set(flower_idx.tolist()), g)
            for key, val in bio.items():
                if key == "rel_hist":
                    continue
                bio_rows.append({"model": mname, "pair_kind": pair_kind[k],
                                 "gene_idx": g, "pheno_idx": p,
                                 "metric": key, "value": val})
            for rname, cnt in bio["rel_hist"].items():
                bio_rows.append({"model": mname, "pair_kind": pair_kind[k],
                                 "gene_idx": g, "pheno_idx": p,
                                 "metric": "rel_count", "relation": rname,
                                 "value": cnt})
            if k % 25 == 0:
                print(f"  [{mname}] {k}/{all_pairs.shape[1]} pairs, "
                      f"{time.time()-t0:.0f}s", flush=True)
        print(f"  [{mname}] done in {time.time()-t0:.0f}s", flush=True)
        # per-model checkpoint so parallel runs never overwrite each other
        tag = "smoke" if args.smoke else "full"
        pd.DataFrame(rows).to_csv(
            os.path.join(C.TABLES_DIR, f"explanations_{tag}_{mname}.csv"), index=False)
        print(f"  wrote {len(rows)} rows -> explanations_{tag}_{mname}.csv", flush=True)
        if path_rows:
            pd.DataFrame(path_rows).to_csv(
                os.path.join(C.TABLES_DIR, f"paths_{tag}_{mname}.csv"), index=False)
        if bio_rows:
            pd.DataFrame(bio_rows).to_csv(
                os.path.join(C.TABLES_DIR, f"path_biology_{tag}_{mname}.csv"), index=False)
        rows, path_rows, bio_rows = [], [], []


if __name__ == "__main__":
    main()
