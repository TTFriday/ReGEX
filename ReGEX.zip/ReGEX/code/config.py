# -*- coding: utf-8 -*-
"""
config.py — shared configuration for the ReGEX explainer (Paper 3).

Reuses the benchmark graph, trained base models and curated gene sets
built by the companion AtMAD-Graph pipeline (paper2_deps/). All paths are
relative to this repository; the ATMAD_* environment variables override
them when data or models live elsewhere.

Layout of this repository
-------------------------
code/            ReGEX explainer and evaluation code (this package)
paper2_deps/     AtMAD-Graph dependency code (models, graph builder, trainer)
  data/          built heterogeneous graph + curated gene sets
  results/models trained base-model checkpoints
results/         explanation results, summary tables and figures
"""
import os

PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # repository root
P2_DIR = os.environ.get("ATMAD_P2_DIR", os.path.join(PROJECT_DIR, "paper2_deps"))
RAW_DATA_DIR = os.environ.get("ATMAD_RAW_DIR", os.path.join(P2_DIR, "rawdata"))
P2_CODE_DIR = P2_DIR                                # models.py lives in paper2_deps/
P2_DATA_DIR = os.path.join(P2_DIR, "data")          # built graph outputs
P2_CURATED_DIR = os.path.join(P2_DATA_DIR, "curated")
P2_MODELS_DIR = os.path.join(P2_DIR, "results", "models")

CODE_DIR = os.path.join(PROJECT_DIR, "code")
RESULTS_DIR = os.path.join(PROJECT_DIR, "results")
TABLES_DIR = os.path.join(RESULTS_DIR, "tables")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")
PAPER_DIR = os.path.join(PROJECT_DIR, "paper")

for d in [RESULTS_DIR, TABLES_DIR, FIGURES_DIR, PAPER_DIR]:
    os.makedirs(d, exist_ok=True)

# --- base-model hyper-parameters (Paper-2 models, seed 42) ---
HIDDEN = 32
GNN_LAYERS = 2
DROPOUT = 0.3
SEED = 42            # base models trained with this seed

# --- explanation sampling ---
N_SAMPLES = 300                 # test (gene, phenotype) pairs to explain
TOP_HOP = 2                     # explanation subgraph = 2-hop neighbourhood
MASK_STEPS = 80                 # Gumbel edge-mask optimisation steps
MASK_LR = 0.05
LAMBDA_SPARSITY = 0.08          # entropy sparsity weight
LAMBDA_GEOM = 0.06              # geometric (graph-distance) prior weight
LAMBDA_REL = 0.04               # relation-prior KL weight
GUMBEL_TAU = 0.5
MASK_THRESHOLD = 0.5            # binarisation threshold for explanation edges
MAX_SUBGRAPH_EDGES = 12000      # cap on 2-hop subgraph size before sampling

# --- path extraction ---
BEAM_WIDTH = 5                  # beam width for path enumeration
MAX_PATH_LEN = 4                # max number of edges in an explanation path
TOP_PATHS = 8                   # top-K paths reported per explanation

# --- evaluation ---
TOP_K_RECALL = 50
FLOWER_PHENO_RE = r"(flower|bolt|vernal|dtf|days.?to)"

import torch as _torch

def load_data():
    return _torch.load(os.path.join(P2_DATA_DIR, "atmad_hetero.pt"),
                       map_location="cpu", weights_only=False)

def load_splits():
    return _torch.load(os.path.join(P2_DATA_DIR, "splits.pt"),
                       map_location="cpu", weights_only=False)
