# -*- coding: utf-8 -*-
"""
make_figures.py — generate Paper 3 figures from full results.

Fig2 : fidelity+ vs sparsity Pareto curves (5 methods, model-pooled)
Fig3 : EGC and rank-IG comparison (bar with error bars)
Fig4 : ReGEX path case study (top paths for one flowering pair)
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TAB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "tables")
FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "figures")
os.makedirs(FIG, exist_ok=True)

MODELS = ["sage", "rgcn", "hgt"]


def load_explanations():
    parts = []
    for m in MODELS:
        fp = os.path.join(TAB, f"explanations_full_{m}.csv")
        if os.path.exists(fp):
            parts.append(pd.read_csv(fp))
    if parts:
        return pd.concat(parts, ignore_index=True)
    return pd.read_csv(os.path.join(TAB, "explanations_full.csv"))


def load_paths():
    parts = []
    for m in MODELS:
        fp = os.path.join(TAB, f"paths_full_{m}.csv")
        if os.path.exists(fp):
            parts.append(pd.read_csv(fp))
    if parts:
        return pd.concat(parts, ignore_index=True)
    return pd.read_csv(os.path.join(TAB, "paths_full.csv"))

METHODS = ["regex", "maskonly", "saliency", "ig", "random"]
METHOD_LABELS = {"regex": "ReGEX", "maskonly": "Mask-Only",
                 "saliency": "Saliency", "ig": "Integrated Gradients",
                 "random": "Random"}
COLORS = {"regex": "#C0392B", "maskonly": "#E67E22", "saliency": "#2980B9",
          "ig": "#8E44AD", "random": "#7F8C8D"}


def fig2():
    df = load_explanations()
    g = df.groupby(["method", "frac"])["fidelity_plus"].median().reset_index()
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for meth in METHODS:
        d = g[g["method"] == meth]
        ax.plot(d["frac"], d["fidelity_plus"], marker="o", linewidth=2,
                color=COLORS[meth], label=METHOD_LABELS[meth])
    ax.axhline(1.0, color="grey", linestyle=":", linewidth=1)
    ax.set_xlabel("Sparsity budget (fraction of edges selected)")
    ax.set_ylabel("Fidelity$^{+}$ (prediction retained)")
    ax.set_xticks([0.05, 0.10, 0.20, 0.50])
    ax.set_xticklabels(["5%", "10%", "20%", "50%"])
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "Fig2_fidelity_sparsity.png"), dpi=300)
    fig.savefig(os.path.join(FIG, "Fig2_fidelity_sparsity.pdf"))
    plt.close(fig)


def fig3():
    df = load_explanations()
    d10 = df[df["frac"] == 0.1]
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.0))
    for ax, metric, ylab in [
            (axes[0], "egc", "EGC"),
            (axes[1], "rank_ig", "rank-IG")]:
        g = d10.groupby("method")[metric]
        means = g.median().reindex(METHODS)
        stds = g.apply(lambda s: np.nanmedian(np.abs(s - np.nanmedian(s)))).reindex(METHODS)
        ax.bar(range(len(METHODS)), means.values,
               yerr=stds.values, capsize=3, color=[COLORS[m] for m in METHODS],
               edgecolor="none", alpha=0.85)
        ax.set_xticks(range(len(METHODS)))
        ax.set_xticklabels([METHOD_LABELS[m] for m in METHODS], rotation=15)
        ax.set_ylabel(ylab)
        ax.grid(axis="y", alpha=0.3)
    axes[0].set_title("(a)", fontsize=11)
    axes[1].set_title("(b)", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "Fig3_egc_rankig.png"), dpi=300)
    fig.savefig(os.path.join(FIG, "Fig3_egc_rankig.pdf"))
    plt.close(fig)


NT_COLOR = {"gene": "#C0392B", "snp": "#2980B9", "cpg": "#27AE60",
            "pathway": "#8E44AD", "phenotype": "#D35400"}


def fig4():
    import json as _json
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..",
                           "atmad_paper2", "data", "node_names.json"),
              encoding="utf-8") as f:
        nn = _json.load(f)
    gn, pn = nn["gene"], nn["phenotype"]
    pt = load_paths()
    d = pt[(pt["reached_target"] == 1)].copy()
    if d.empty:
        d = pt.copy()
    d = d.sort_values("score", ascending=False)
    # prefer a path that spans >=2 distinct molecular layers (strip _rev)
    d["n_layers"] = d["relations"].apply(
        lambda r: len(set(x.replace("_rev", "") for x in str(r).split(";"))))
    pick = d[d["n_layers"] >= 2]
    if pick.empty:
        pick = d
    row = pick.iloc[0]
    nodes = [x for x in str(row["nodes_global"]).split(";")]
    rels = [x for x in str(row["relations"]).split(";")]
    if not nodes:
        return
    n = len(nodes)
    fig, ax = plt.subplots(figsize=(10.0, 3.2))
    ax.axis("off")
    xs = np.linspace(0.08, 0.92, n)
    for i, nd in enumerate(nodes):
        t, gid = nd.split(":", 1)
        name = f"{t}:{gid}"
        if t == "gene" and int(gid) < len(gn):
            name = gn[int(gid)]
        elif t == "phenotype" and int(gid) < len(pn):
            name = pn[int(gid)]
        fc = NT_COLOR.get(t, "#ECF0F1")
        ax.text(xs[i], 0.55, name, ha="center", va="center", fontsize=9,
                fontweight="bold" if i == 0 else "normal",
                bbox=dict(boxstyle="round,pad=0.45", fc=fc, ec="none",
                          alpha=0.88 if i == 0 else 0.28))
        if i < len(rels):
            ax.annotate("", xy=(xs[i + 1], 0.55), xytext=(xs[i], 0.55),
                        arrowprops=dict(arrowstyle="->", lw=1.6,
                                        color="#34495E"))
            ax.text((xs[i] + xs[i + 1]) / 2, 0.68, rels[i], ha="center",
                    fontsize=8, color="#34495E")
    ax.set_title(f"ReGEX explanation path (gene {row['gene_idx']} -> phenotype "
                 f"{row['pheno_idx']}, score={row['score']:.3f})", fontsize=11)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "Fig4_path_case.png"), dpi=300)
    fig.savefig(os.path.join(FIG, "Fig4_path_case.pdf"))
    plt.close(fig)


if __name__ == "__main__":
    fig2()
    fig3()
    fig4()
    print("figures written to", FIG)
