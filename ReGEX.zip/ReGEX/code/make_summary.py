# -*- coding: utf-8 -*-
"""
make_summary.py — aggregate Paper 3 results into manuscript tables.

Reads per-model result files (explanations_full_{model}.csv,
path_biology_full_{model}.csv) and writes manuscript-ready summary tables
to results/tables/summary_*.csv.

Fidelity metrics are right-skewed (occasional prediction reorganisation
outliers), so learned-mask vs gradient comparisons use the median and the
median absolute deviation (MAD); path biology fractions (0-1) use mean+SD.
"""
import os
import numpy as np
import pandas as pd

TAB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "tables")
MODELS = ["sage", "rgcn", "hgt"]


def load_explanations():
    parts = []
    for m in MODELS:
        fp = os.path.join(TAB, f"explanations_full_{m}.csv")
        if os.path.exists(fp):
            parts.append(pd.read_csv(fp))
    if parts:
        return pd.concat(parts, ignore_index=True)
    fp = os.path.join(TAB, "explanations_full.csv")  # legacy single file
    return pd.read_csv(fp)


def load_path_biology():
    parts = []
    for m in MODELS:
        fp = os.path.join(TAB, f"path_biology_full_{m}.csv")
        if os.path.exists(fp):
            parts.append(pd.read_csv(fp))
    if parts:
        return pd.concat(parts, ignore_index=True)
    fp = os.path.join(TAB, "path_biology_full.csv")  # legacy single file
    return pd.read_csv(fp)


def mad(s):
    med = np.nanmedian(s)
    return float(np.nanmedian(np.abs(np.asarray(s, dtype=float) - med)))


def fmt_med_mad(s):
    m = np.nanmedian(s)
    d = mad(s)
    if np.isnan(m):
        return "n/a"
    return f"{m:.3f}\u00b1{d:.3f}"


def fmt_mean_std(s):
    m = np.nanmean(s)
    sd = np.nanstd(s)
    if np.isnan(m):
        return "n/a"
    return f"{m:.3f}\u00b1{sd:.3f}"


def main():
    df = load_explanations()
    cols = ["fidelity_plus", "fidelity_minus", "sparsity", "egc", "rank_ig"]

    # Table: method x frac, pooled over models and pair kinds (median +/- MAD)
    g = df.groupby(["method", "frac"])[cols].agg(lambda s: fmt_med_mad(s))
    g = g.reset_index()
    g.to_csv(os.path.join(TAB, "summary_method_frac.csv"), index=False)

    # numeric variant for downstream plotting (median / mad)
    med = df.groupby(["method", "frac"])[cols].median().reset_index()
    madm = df.groupby(["method", "frac"])[cols].apply(
        lambda x: pd.Series({c: mad(x[c]) for c in cols})).reset_index()
    g2 = med.merge(madm, on=["method", "frac"], suffixes=("_median", "_mad"))
    g2.to_csv(os.path.join(TAB, "summary_method_frac_numeric.csv"), index=False)

    # Table: main results at frac=0.1 (model-pooled)
    d10 = df[df["frac"] == 0.1]
    rows = []
    for meth, s in d10.groupby("method"):
        row = {"method": meth}
        for c in cols:
            row[c + "_median"] = np.nanmedian(s[c])
            row[c + "_mad"] = mad(s[c])
        rows.append(row)
    g3 = pd.DataFrame(rows)
    g3.to_csv(os.path.join(TAB, "summary_main_frac10.csv"), index=False)

    # Table: per-model comparison at frac=0.1
    rows = []
    for (mname, meth), s in d10.groupby(["model", "method"]):
        rows.append({"model": mname, "method": meth,
                     "fidelity_plus_median": np.nanmedian(s["fidelity_plus"]),
                     "fidelity_plus_mad": mad(s["fidelity_plus"]),
                     "egc_median": np.nanmedian(s["egc"]),
                     "egc_mad": mad(s["egc"])})
    g4 = pd.DataFrame(rows)
    g4.to_csv(os.path.join(TAB, "summary_per_model_frac10.csv"), index=False)

    # Table: path biology pooled (mean +/- std; fractions in [0,1])
    pb = load_path_biology()
    # a pair has at least one extracted path iff it produced rel_count rows
    rel = pb[pb["metric"] == "rel_count"]
    has_path = rel[["model", "gene_idx", "pheno_idx"]].drop_duplicates()
    bio = pb[pb["metric"].isin(["seed_fraction", "pass_fraction"])]
    bio_cond = bio.merge(has_path, on=["model", "gene_idx", "pheno_idx"],
                         how="inner")
    g5 = bio_cond.groupby(["model", "pair_kind", "metric"])["value"].agg(
        ["mean", "std"])
    g5 = g5.reset_index()
    # path coverage: fraction of pairs with at least one extracted path
    def _cov(x):
        m = x.name[0]  # groupby keys are excluded from the frame
        hp = has_path[has_path["model"] == m][["gene_idx", "pheno_idx"]]
        uni = x[["gene_idx", "pheno_idx"]].drop_duplicates()
        if len(uni) == 0:
            return pd.Series({"coverage": np.nan})
        return pd.Series({"coverage": len(hp.merge(uni, how="inner")) / len(uni)})

    cov = pb.groupby(["model", "pair_kind"]).apply(_cov).reset_index()
    cov = cov.rename(columns={"coverage": "value"})
    cov["metric"] = "path_coverage"
    g5 = pd.concat([g5, cov[["model", "pair_kind", "metric", "value"]]],
                   ignore_index=True)
    g5.to_csv(os.path.join(TAB, "summary_path_biology.csv"), index=False)

    # relation histogram pooled (normalised to layer-level labels)
    rel = pb[pb["metric"] == "rel_count"]
    rel = rel.copy()
    rel["layer"] = rel["relation"].str.replace("_rev", "", regex=False)
    g6 = rel.groupby("layer")["value"].sum().sort_values(ascending=False)
    g6.to_csv(os.path.join(TAB, "summary_rel_hist.csv"))

    print("wrote summary tables:")
    for f in ["summary_method_frac.csv", "summary_method_frac_numeric.csv",
              "summary_main_frac10.csv", "summary_per_model_frac10.csv",
              "summary_path_biology.csv", "summary_rel_hist.csv"]:
        print("  ", f)


if __name__ == "__main__":
    main()
