# -*- coding: utf-8 -*-
"""
paths.py — beam-search path extraction and biological validation for Paper 3.

Given explanation edge weights for a target (gene g, phenotype p) pair,
enumerate the top-K weighted paths that connect g toward its supporting
omic evidence, using beam search over relation-typed edges.

Node ids inside the subgraph are flattened across node types with the same
offset scheme used by the GNN encoder (see models.type_offsets), so the
adjacency is type-consistent.
"""
import numpy as np
import pandas as pd

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C


def type_offsets(sub):
    offs, off = {}, 0
    for nt in sub.node_types:
        offs[nt] = off
        off += sub[nt].num_nodes
    return offs


def flatten_edges(sub):
    """Flat edge list [(src_flat, rel, dst_flat, weight)] across edge types."""
    offs = type_offsets(sub)
    flat = []
    for (s, r, d), v in sub.edge_items():
        ei = v.edge_index.numpy()
        for k in range(ei.shape[1]):
            flat.append((int(ei[0, k]) + offs[s], r,
                         int(ei[1, k]) + offs[d], 1.0))
    return flat


def build_weighted_adjacency(sub, weights, thresh=0.5):
    """weighted adjacency on explanation edges (flattened local indices)."""
    offs = type_offsets(sub)
    adj = {}
    for (s, r, d), v in sub.edge_items():
        w = weights[(s, r, d)]
        sel = np.where(w >= thresh)[0]
        if len(sel) == 0:
            continue
        ei = v.edge_index.numpy()
        for k in sel:
            a = int(ei[0, k]) + offs[s]
            b = int(ei[1, k]) + offs[d]
            wt = float(w[k])
            rev_label = r[:-4] if r.endswith("_rev") else r + "_rev"
            adj.setdefault(a, []).append((r, b, wt))
            adj.setdefault(b, []).append((rev_label, a, wt))
    return adj


def beam_paths(adj, start, max_len=4, beam=5, top_k=8, targets=None):
    """Beam search: paths from `start`, scored by geometric-mean edge weight;
    paths reaching any target node are preferred."""
    beams = [(start, [], 1.0, False)]
    finished = []
    for _ in range(max_len):
        nxt = []
        for node, path, score, reached in beams:
            for r, nb, wt in adj.get(node, []):
                if nb in path:
                    continue
                sc = score * (wt + 1e-3)
                is_target = targets is not None and nb in targets
                nxt.append((nb, path + [(node, r, nb, wt)], sc,
                            reached or is_target))
        nxt.sort(key=lambda x: (-x[3], -x[2]))
        beams = nxt[:beam]
        for b in beams:
            if b[3]:
                finished.append(b)
        if not beams:
            break
    finished.sort(key=lambda x: (-x[3], -x[2]))
    res = finished[:top_k]
    if len(res) < top_k and beams:
        for b in beams:
            if b not in res:
                res.append(b)
        res = res[:top_k]
    return res


def flat_to_global(sub, local):
    """flattened subgraph index -> (node_type, global_idx)."""
    offs = type_offsets(sub)
    f2g = {}
    for nt in sub.node_types:
        for gidx, pos in local.get(nt, {}).items():
            f2g[offs[nt] + pos] = (nt, gidx)
    return f2g


def node_name(nt, idx, gene_names, pheno_names, snp_names=None,
              cpg_names=None, pw_names=None):
    maps = {"gene": gene_names, "phenotype": pheno_names}
    if snp_names:
        maps["snp"] = snp_names
    if cpg_names:
        maps["cpg"] = cpg_names
    if pw_names:
        maps["pathway"] = pw_names
    m = maps.get(nt)
    if m is None or idx >= len(m):
        return f"{nt}:{idx}"
    return m[idx]


def extract_paths(sub, weights, local, start_g_global, targets_global,
                  gene_names, pheno_names, top_k=8):
    """Return (paths, f2g). targets_global: iterable of (nt, global_idx)
    target nodes; the seed's own curated-gene target set is included."""
    offs = type_offsets(sub)
    adj = build_weighted_adjacency(sub, weights, thresh=C.MASK_THRESHOLD)
    start_flat = offs["gene"] + local["gene"][start_g_global]
    target_flats = set()
    for (nt, gidx) in targets_global:
        if gidx in local.get(nt, {}):
            target_flats.add(offs[nt] + local[nt][gidx])
    paths = beam_paths(adj, start_flat, max_len=C.MAX_PATH_LEN,
                       beam=C.BEAM_WIDTH, top_k=top_k, targets=target_flats)
    f2g = flat_to_global(sub, local)
    out = []
    for node, trace, score, reached in paths:
        nodes_flat = [start_flat] + [t[2] for t in trace]
        nodes_global = [f2g[n] for n in nodes_flat if n in f2g]
        out.append({"score": score, "reached_target": bool(reached),
                    "nodes_global": nodes_global, "relations": [t[1] for t in trace],
                    "length": len(trace)})
    return out, f2g


def path_biology(paths, curated_set, gene_idx_global_of_seed):
    """Biology checks on extracted paths:
    - fraction of paths whose seed (the explained gene) is a curated flowering
      gene,
    - fraction of paths that pass through at least one curated flowering gene
      (including seed),
    - relation-type histogram across all paths."""
    n_paths = max(len(paths), 1)
    seed_hit, pass_hit = 0, 0
    rel_hist = {}
    for p in paths:
        glob_genes = [g for (nt, g) in p["nodes_global"] if nt == "gene"]
        seed_is_curated = gene_idx_global_of_seed in curated_set
        any_curated = seed_is_curated or any(g in curated_set for g in glob_genes)
        seed_hit += int(seed_is_curated)
        pass_hit += int(any_curated)
        for r in p["relations"]:
            rel_hist[r] = rel_hist.get(r, 0) + 1
    return {"seed_fraction": seed_hit / n_paths,
            "pass_fraction": pass_hit / n_paths,
            "rel_hist": rel_hist}
