# -*- coding: utf-8 -*-
"""stats_subgraph.py — compute Table 1 subgraph statistics on a sample of pairs."""
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C
from explainers import build_subgraph


def main():
    data = C.load_data()
    splits = C.load_splits()
    nn = json.load(open(os.path.join(C.P2_DATA_DIR, "node_names.json"), encoding="utf-8"))
    pheno_list = nn["phenotype"]
    pheno_map = {p: i for i, p in enumerate(pheno_list)}
    import re
    FLOWER_RE = re.compile(C.FLOWER_PHENO_RE, re.I)
    flow_pheno = [pheno_map[p] for p in pheno_list if FLOWER_RE.search(p)]
    test_pos = splits["test_pos"]
    cold = set(splits["cold_phenotypes"])
    idx = [i for i in range(test_pos.shape[1]) if test_pos[1, i] not in cold]
    rng = np.random.default_rng(7)
    pick = rng.choice(idx, 30, replace=False)
    pairs = [(int(test_pos[0, i]), int(test_pos[1, i])) for i in pick]
    for p in flow_pheno[:5]:
        pairs.append((int(0), int(p)))

    n_nodes, n_edges = [], []
    n_type = {}
    for g, p in pairs:
        sub, keep, local, _ = build_subgraph(data, g, p)
        n_nodes.append(sum(sub[nt].num_nodes for nt in sub.node_types))
        n_edges.append(sum(v.edge_index.shape[1] for _, v in sub.edge_items()))
        for nt in sub.node_types:
            n_type[nt] = n_type.get(nt, 0) + sub[nt].num_nodes
    print("sample pairs:", len(pairs))
    print("subgraph nodes: median=%.0f  mean=%.1f  min=%d  max=%d" %
          (np.median(n_nodes), np.mean(n_nodes), min(n_nodes), max(n_nodes)))
    print("subgraph edges: median=%.0f  mean=%.1f  min=%d  max=%d" %
          (np.median(n_edges), np.mean(n_edges), min(n_edges), max(n_edges)))
    for nt, c in sorted(n_type.items(), key=lambda x: -x[1]):
        print(f"  nodes by type {nt}: {c}")


if __name__ == "__main__":
    main()
