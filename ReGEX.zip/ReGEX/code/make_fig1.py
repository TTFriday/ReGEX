# -*- coding: utf-8 -*-
"""
make_fig1.py — Figure 1: schematic of ReGEX (three panels).

(a) 2-hop subgraph around a query (gene, phenotype) pair with typed edges;
(b) Gumbel-sigmoid edge-mask learning with three regularisers;
(c) layer-resolved path extraction from the masked subgraph.
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "figures")
os.makedirs(FIG, exist_ok=True)

NT_COLOR = {"gene": "#C0392B", "snp": "#2980B9", "cpg": "#27AE60",
            "pathway": "#8E44AD", "phenotype": "#D35400"}
REL_COLOR = {"eqtl": "#3498DB", "gwas": "#9B59B6", "twas": "#E67E22",
             "emqtl": "#1ABC9C", "ewas": "#2ECC71", "pheno_path": "#95A5A6"}


def node_patch(ax, x, y, label, ntype, r=0.42, fs=8):
    c = NT_COLOR.get(ntype, "#BDC3C7")
    ax.add_patch(plt.Circle((x, y), r, fc=c, ec="none", alpha=0.35 if ntype != "gene" else 0.9))
    ax.text(x, y, label, ha="center", va="center", fontsize=fs,
            fontweight="bold" if ntype in ("gene", "phenotype") else "normal",
            color="white" if ntype in ("gene", "phenotype") else "#2C3E50")


def edge(ax, a, b, rel, ls="-", lw=1.3):
    ax.plot([a[0], b[0]], [a[1], b[1]], ls=ls, lw=lw,
            color=REL_COLOR.get(rel, "#7F8C8D"), zorder=1)
    mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
    ax.text(mx, my, rel, fontsize=6.5, color=REL_COLOR.get(rel, "#7F8C8D"),
            ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))


def panel_a(ax):
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    # query nodes
    g = (3.2, 5.2); p = (3.2, 1.8)
    node_patch(ax, *g, "g", "gene", r=0.55, fs=10)
    node_patch(ax, *p, "p", "phenotype", r=0.5, fs=10)
    # neighbours
    snp = (6.4, 7.2); cpg = (6.2, 3.0); pw = (1.0, 8.4); g2 = (8.0, 5.2)
    node_patch(ax, *snp, "SNP", "snp")
    node_patch(ax, *cpg, "CpG", "cpg")
    node_patch(ax, *pw, "PW", "pathway")
    node_patch(ax, *g2, "g'", "gene")
    # typed edges
    edge(ax, g, p, "twas")
    edge(ax, g, snp, "eqtl", ls=(0, (4, 2)))
    edge(ax, g, g2, "eqtl", ls=(0, (4, 2)))
    edge(ax, g, cpg, "emqtl", ls=(0, (2, 2)))
    edge(ax, cpg, p, "ewas", ls=(0, (2, 2)))
    edge(ax, g, pw, "pheno_path", ls=(0, (1, 2)))
    ax.set_title("(a) typed 2-hop subgraph $S_{g,p}$", fontsize=11)


def panel_b(ax):
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    # left: subgraph with variable masks
    g = (2.6, 5.4); p = (2.6, 2.4)
    node_patch(ax, *g, "g", "gene", r=0.55, fs=10)
    node_patch(ax, *p, "p", "phenotype", r=0.5, fs=10)
    snp = (5.4, 7.4); cpg = (5.2, 3.4)
    node_patch(ax, *snp, "SNP", "snp")
    node_patch(ax, *cpg, "CpG", "cpg")
    edge(ax, g, p, "twas", lw=2.2)
    edge(ax, g, snp, "eqtl", lw=0.9)
    edge(ax, g, cpg, "emqtl", lw=1.5)
    edge(ax, cpg, p, "ewas", lw=0.7)
    ax.text(1.3, 8.6, "masks  $m_e$", fontsize=9)
    ax.annotate("", xy=(5.9, 5.4), xytext=(4.6, 5.4),
                arrowprops=dict(arrowstyle="->", lw=1.6, color="#2C3E50"))
    # middle: regularisers
    ax.text(6.3, 8.9, "regularisers", fontsize=10, fontweight="bold")
    regs = ["$\\mathcal{L}_{\\mathrm{sparse}}$ entropy",
            "$\\mathcal{L}_{\\mathrm{geom}}$ distance",
            "$\\mathcal{L}_{\\mathrm{rel}}$ KL(type)"]
    for i, t in enumerate(regs):
        ax.text(6.3, 7.4 - 1.5 * i, t, fontsize=9,
                bbox=dict(boxstyle="round,pad=0.35", fc="#F7F9F9",
                          ec="#BDC3C7", lw=0.8))
    ax.annotate("", xy=(9.15, 5.4), xytext=(7.9, 5.4),
                arrowprops=dict(arrowstyle="->", lw=1.6, color="#2C3E50"))
    # right: masked subgraph
    node_patch(ax, *g, "g", "gene", r=0.55, fs=10)
    node_patch(ax, *p, "p", "phenotype", r=0.5, fs=10)
    node_patch(ax, *cpg, "CpG", "cpg")
    edge(ax, g, p, "twas", lw=2.4)
    edge(ax, g, cpg, "emqtl", lw=1.4)
    ax.text(9.15, 8.9, "$S_m$", fontsize=10)
    ax.text(9.15, 8.3, "sparse &", fontsize=8)
    ax.text(9.15, 7.7, "local", fontsize=8)
    ax.set_title("(b) Gumbel mask learning", fontsize=11)


def panel_c(ax):
    ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis("off")
    g = (1.2, 5.4); p = (8.8, 5.4)
    node_patch(ax, *g, "g", "gene", r=0.55, fs=10)
    node_patch(ax, *p, "p", "phenotype", r=0.5, fs=10)
    snp = (3.4, 7.6); cpg = (5.6, 3.2); pw = (6.0, 7.6); g2 = (3.4, 3.2)
    node_patch(ax, *snp, "SNP", "snp")
    node_patch(ax, *cpg, "CpG", "cpg")
    node_patch(ax, *pw, "PW", "pathway")
    node_patch(ax, *g2, "g'", "gene")
    edge(ax, g, snp, "eqtl", lw=2.0)
    edge(ax, snp, pw, "gwas", lw=2.0)
    edge(ax, pw, p, "pheno_path", lw=2.0)
    edge(ax, g, g2, "eqtl", lw=0.6)
    edge(ax, g2, cpg, "emqtl", lw=0.6)
    edge(ax, cpg, p, "ewas", lw=0.6)
    # highlight the main path
    ax.plot([1.2, 3.4], [5.4, 7.6], lw=3.5, color="#E67E22", alpha=0.25, zorder=0)
    ax.plot([3.4, 6.0], [7.6, 7.6], lw=3.5, color="#E67E22", alpha=0.25, zorder=0)
    ax.plot([6.0, 8.8], [7.6, 5.4], lw=3.5, color="#E67E22", alpha=0.25, zorder=0)
    ax.set_title("(c) layer-resolved paths (gene$\\rightarrow$SNP$\\rightarrow$pathway$\\rightarrow$phenotype)",
                 fontsize=11)


def main():
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.0))
    panel_a(axes[0]); panel_b(axes[1]); panel_c(axes[2])
    fig.suptitle("ReGEX: relation-aware geometric explainer", fontsize=13, y=1.0)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "Fig1_schema.png"), dpi=300,
                bbox_inches="tight")
    fig.savefig(os.path.join(FIG, "Fig1_schema.pdf"),
                bbox_inches="tight")
    plt.close(fig)
    print("Fig1 written to", FIG)


if __name__ == "__main__":
    main()
