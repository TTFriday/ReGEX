# -*- coding: utf-8 -*-
"""
evaluate.py — FSC evaluation framework for Paper 3.

Every method produces a per-edge weight vector on the SAME 2-hop subgraph.
Evaluation selects the globally top-K edges (K = frac * n_edges) as the
explanation subgraph, so all methods are compared at identical sparsity
budgets (frac = 0.05 / 0.10 / 0.20 / 0.50), giving a fidelity–sparsity
Pareto view.

Metrics (per target pair):
  fidelity+ : prediction retained when ONLY the top-K edges are kept
              (normalised: s_keep / s_full)
  fidelity- : prediction drop when the top-K edges are removed
              (normalised: (s_full - s_remove) / |s_full|)
  sparsity  : K / n_edges (identical across methods at a given frac)
  EGC       : Spearman between explanation edge mass on each gene and its
              independent omics evidence (>= 10 genes)
  rank-IG   : Spearman between method edge weights and IG edge weights
"""
import numpy as np
import torch
from scipy.stats import spearmanr
from explainers import score_pair


def topk_mask(sub, weights, K):
    """Globally top-K edges by weight -> per-edge-type boolean mask."""
    keys, ww = [], []
    for (s, r, d) in sub.edge_types:
        w = weights[(s, r, d)]
        if len(w) == 0:
            continue
        ww.append(w)
        keys.append((s, r, d))
    if not ww:
        return {}
    allw = np.concatenate(ww)
    K = max(1, min(int(K), len(allw)))
    order = np.argsort(-allw)[:K]
    sel = set(order.tolist())
    mask = {}
    off = 0
    for (s, r, d), w in zip(keys, ww):
        n = len(w)
        m = np.zeros(n, dtype=bool)
        for j in range(n):
            if (off + j) in sel:
                m[j] = True
        mask[(s, r, d)] = m
        off += n
    return mask


def prediction_keep(model, sub, mask, g_local, p_local, data=None):
    eid = {}
    for (s, r, d), v in sub.edge_items():
        ei = v.edge_index
        m = mask.get((s, r, d), np.zeros(ei.shape[1], dtype=bool))
        eid[(s, r, d)] = ei[:, m] if m.any() else \
            ei[:, torch.zeros(ei.shape[1], dtype=torch.bool)]
    return score_pair(model, sub, g_local, p_local, data=data, eid=eid)


def prediction_remove(model, sub, mask, g_local, p_local, data=None):
    eid = {}
    for (s, r, d), v in sub.edge_items():
        ei = v.edge_index
        m = mask.get((s, r, d), np.zeros(ei.shape[1], dtype=bool))
        keep = ~m
        eid[(s, r, d)] = ei[:, keep] if keep.any() else \
            ei[:, torch.zeros(ei.shape[1], dtype=torch.bool)]
    return score_pair(model, sub, g_local, p_local, data=data, eid=eid)


def gene_evidence_egc(sub, mask, evidence_map, local=None):
    """Spearman between explanation edge mass on each gene node and its
    independent omics evidence (needs >= 10 genes with nonzero total mass).
    Mass counts every explained edge incident to a gene node. Subgraph
    edge indices are type-local; `local` maps (type, global_idx) -> local
    position and is used to recover the global gene index for evidence lookup."""
    mass = {}
    for (s, r, d), v in sub.edge_items():
        m = mask.get((s, r, d), np.zeros(v.edge_index.shape[1], dtype=bool))
        if not m.any():
            continue
        ei = v.edge_index.numpy()
        if s == "gene":
            for a in ei[0, m]:
                mass[int(a)] = mass.get(int(a), 0.0) + 1.0
        if d == "gene":
            for b in ei[1, m]:
                mass[int(b)] = mass.get(int(b), 0.0) + 1.0
    if len(mass) < 10:
        return np.nan
    g2g = local.get("gene", {}) if local else {}
    inv = {v: k for k, v in g2g.items()}
    genes = list(mass.keys())
    x = np.array([mass[g] for g in genes])
    y = np.array([evidence_map.get(inv.get(g, -1), 0.0) for g in genes])
    if x.std() == 0 or y.std() == 0:
        return np.nan
    return float(spearmanr(x, y).statistic)


def rank_agreement(sub, weights_a, weights_b):
    va, vb = [], []
    for (s, r, d) in sub.edge_types:
        va.append(weights_a[(s, r, d)].ravel())
        vb.append(weights_b[(s, r, d)].ravel())
    va = np.concatenate(va); vb = np.concatenate(vb)
    if len(va) < 5 or va.std() == 0 or vb.std() == 0:
        return np.nan
    return float(spearmanr(va, vb).statistic)


def evaluate_pair(model, sub, weights, g_local, p_local, evidence_map,
                  ig_weights, frac, data=None, local=None):
    n_total = sum(v.edge_index.shape[1] for _, v in sub.edge_items())
    if n_total == 0:
        return {"fidelity_plus": np.nan, "fidelity_minus": np.nan,
                "sparsity": np.nan, "egc": np.nan, "rank_ig": np.nan,
                "n_selected": 0, "n_total": 0, "s_full": 0.0}
    K = int(frac * n_total)
    mask = topk_mask(sub, weights, K)
    s_full = score_pair(model, sub, g_local, p_local, data=data)
    s_keep = prediction_keep(model, sub, mask, g_local, p_local, data=data)
    s_rem = prediction_remove(model, sub, mask, g_local, p_local, data=data)
    fid_plus = s_keep / (abs(s_full) + 1e-9)
    fid_minus = (s_full - s_rem) / (abs(s_full) + 1e-9)
    egc = gene_evidence_egc(sub, mask, evidence_map, local=local)
    r_ig = rank_agreement(sub, weights, ig_weights) if ig_weights else np.nan
    return {"fidelity_plus": fid_plus, "fidelity_minus": fid_minus,
            "sparsity": K / max(n_total, 1), "egc": egc,
            "rank_ig": r_ig, "n_selected": K, "n_total": n_total,
            "s_full": s_full}
