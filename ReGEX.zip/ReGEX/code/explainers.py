# -*- coding: utf-8 -*-
"""
explainers.py — ReGEX and baseline explanation methods for Paper 3.

Methods
-------
ReGEX        : relation-aware geometric explainer. Learns a Gumbel edge mask
               on the 2-hop subgraph of a target (gene, phenotype) pair with
               three regularisers:
                 L = -logit(masked prediction)   [fidelity]
                     + L_sparse (mask entropy)   [sparsity]
                     + L_geom  (graph-distance)  [geometry]
                     + L_rel   (relation KL)     [relation prior]
               Straight-through Gumbel: hard mask forward, soft gradients.
MaskOnly     : GNNExplainer-style ablation (fidelity + sparsity only, no
               geometry / relation terms) on the same subgraph.
SaliencyEdge : input-gradient node saliency combined into edge weights.
IGEdge       : integrated-gradients node attribution combined into edge
               weights (zero baseline, 40 steps).
RandomEdge   : uniform random edge weights.

All methods output, for each target pair, a subgraph edge-weight vector on
the SAME 2-hop subgraph, which makes metrics directly comparable.
"""
import os, sys
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C
sys.path.insert(0, C.P2_CODE_DIR)          # models.py lives in Paper-2 code/
from models import LinkPredictor, type_offsets, flatten_edges
from torch_geometric.data import HeteroData


# --------------------------------------------------------------------------
# subgraph construction
# --------------------------------------------------------------------------
def node_type_of(data, idx):
    """Node type by global flattened offset (Paper-2 models.py convention)."""
    offs = type_offsets(data)
    types = list(data.node_types)
    for i, nt in enumerate(types):
        nxt = offs[nt] + data[nt].num_nodes
        if idx < nxt:
            return nt
    raise ValueError(idx)


def build_subgraph(data, gene_idx, pheno_idx, max_edges=C.MAX_SUBGRAPH_EDGES,
                   hop=C.TOP_HOP, max_deg=50):
    """Bounded 2-hop induced subgraph around the target (gene, phenotype) pair.

    Nodes are identified by (node_type, type-local index) tuples because
    HeteroData stores each type's indices separately. Neighbourhood growth is
    degree-capped (max_deg edges per node per hop) so that explanation
    subgraphs stay tractable on the large benchmark graph.
    """
    adj = {}
    for (s, r, d), v in data.edge_items():
        if r.endswith("_rev"):
            continue  # explicit reverse edges stored; add manually below
        ei = v.edge_index
        for a, b in zip(ei[0].tolist(), ei[1].tolist()):
            adj.setdefault((s, int(a)), []).append((r, (d, int(b))))
            adj.setdefault((d, int(b)), []).append((r + "_rev", (s, int(a))))

    rng = np.random.default_rng(0)
    keep = {("gene", int(gene_idx)), ("phenotype", int(pheno_idx))}
    frontier = [("gene", int(gene_idx)), ("phenotype", int(pheno_idx))]
    seen_e = set()
    for h in range(hop):
        nxt = []
        for u in frontier:
            nbrs = adj.get(u, [])
            if len(nbrs) > max_deg:
                pick = rng.choice(len(nbrs), max_deg, replace=False)
                nbrs = [nbrs[i] for i in pick]
            for r, (nt, v) in nbrs:
                if (u, r, (nt, v)) in seen_e:
                    continue
                seen_e.add((u, r, (nt, v)))
                if (nt, v) not in keep:
                    keep.add((nt, v))
                    nxt.append((nt, v))
        frontier = nxt
        if not frontier:
            break

    keep = sorted(keep)   # (nt, idx) tuples
    edges = list(seen_e)
    if len(edges) > max_edges:
        rng2 = np.random.default_rng(0)
        edges = [edges[i] for i in rng2.choice(len(edges), max_edges, replace=False)]

    # local index per (type, global-local idx)
    local = {}
    for nt in data.node_types:
        ids = [idx for (t, idx) in keep if t == nt]
        local[nt] = {idx: k for k, idx in enumerate(ids)}

    sub = HeteroData()
    for nt in data.node_types:
        ids = [idx for (t, idx) in keep if t == nt]
        if ids:
            sub[nt].x = data[nt].x[torch.tensor(ids)]
            sub[nt].num_nodes = len(ids)
        else:
            sub[nt].x = torch.zeros((0, data[nt].x.shape[1]))
            sub[nt].num_nodes = 0
    for (s, r, d) in data.edge_types:
        sids = local[s]; dids = local[d]
        pairs = [(sids[a], dids[b]) for ((t_a, a), rr, (t_b, b)) in edges
                 if rr == r and t_a == s and t_b == d and a in sids and b in dids]
        if pairs:
            ei = torch.tensor(pairs, dtype=torch.long).t().contiguous()
            sub[(s, r, d)].edge_index = ei
    return sub, keep, local, edges


def local_index(keep, nt, idx):
    """(node_type, type-local index) -> position in the subgraph node list."""
    for k, (t, i) in enumerate(keep):
        if t == nt and i == idx:
            return k
    raise ValueError((nt, idx))


# --------------------------------------------------------------------------
# model restore
# --------------------------------------------------------------------------
def restore_model(model_name, data, ckpt):
    feats = {nt: data[nt].x.shape[1] for nt in data.node_types}
    metadata = (list(data.node_types), list(data.edge_types))
    model = LinkPredictor(feats, C.HIDDEN, C.HIDDEN, model_name=model_name,
                          metadata=metadata, num_relations=len(data.edge_types),
                          num_heads=2, dropout=C.DROPOUT, num_layers=C.GNN_LAYERS)
    model.load_state_dict(ckpt["state"])
    model.eval()
    return model


def score_pair(model, sub, g_local, p_local, data=None, eid=None):
    """Score the target pair on a subgraph (local indices).

    eid: optional {edge_type: edge_index} to score on a masked edge set;
    defaults to all subgraph edges.
    """
    with torch.no_grad():
        nt_order = data.node_types if data is not None else list(sub.node_types)
        xd = {nt: sub[nt].x for nt in nt_order}
        if eid is None:
            eid = {et: v.edge_index for et, v in sub.edge_items()}
        emb = model.encode(sub, xd, eid)
    return float((emb["gene"][g_local] * emb["phenotype"][p_local]).sum())


def gumbel_sigmoid(logits, tau):
    """Reparameterised sigmoid with logistic noise, numerically stable.
    u ~ U(0,1); soft = sigmoid((logit + log u - log(1-u)) / tau) in (0,1)."""
    u = torch.rand_like(logits).clamp_min(1e-6).clamp_max(1 - 1e-6)
    noise = torch.log(u) - torch.log(1 - u)
    return torch.sigmoid((logits + noise) / tau)


def _hard_masks(soft):
    return [torch.bernoulli(m).bool() for m in soft]


def _final_masks(logs, tau):
    with torch.no_grad():
        soft_f = [gumbel_sigmoid(l, tau) for l in logs]
        hard_f = [torch.bernoulli(m).bool() for m in soft_f]
    return soft_f, hard_f


# --------------------------------------------------------------------------
# ReGEX: Gumbel edge-mask learning with geometric + relation priors
# --------------------------------------------------------------------------
def _edge_type_counts(sub):
    counts = {}
    total = 0
    for (s, r, d), v in sub.edge_items():
        n = v.edge_index.shape[1]
        counts[(s, r, d)] = n
        total += n
    return counts, max(total, 1)


def _relation_prior(sub, counts, total):
    q = []
    for (s, r, d), v in sub.edge_items():
        q.append(counts[(s, r, d)] / total)
    return np.array(q, dtype=np.float32)


def _edge_type_ids(sub):
    return [i for i, (s, r, d) in enumerate(sub.edge_types)]


def _edge_dist_to_seeds(sub, local, gene_idx, pheno_idx):
    """min graph distance from each subgraph edge's endpoints to the seeds
    (computed on the subgraph adjacency, <= 2 hops)."""
    # adjacency on subgraph edges (local indices)
    adj = {}
    for i, (s, r, d) in enumerate(sub.edge_types):
        ei = sub[(s, r, d)].edge_index.numpy()
        for a, b in zip(ei[0], ei[1]):
            adj.setdefault(int(a), []).append(int(b))
            adj.setdefault(int(b), []).append(int(a))
    seeds = {local["gene"][gene_idx], local["phenotype"][pheno_idx]}
    dist = {s: 0 for s in seeds}
    frontier = list(seeds)
    hop = 0
    while frontier and hop < 2:
        nxt = []
        for u in frontier:
            for v in adj.get(u, []):
                if v not in dist:
                    dist[v] = hop + 1
                    nxt.append(v)
        frontier = nxt
        hop += 1
    # edge distance = min over endpoints (missing -> 3)
    ed = []
    for i, (s, r, d) in enumerate(sub.edge_types):
        ei = sub[(s, r, d)].edge_index.numpy()
        ds = [dist.get(int(a), 3) for a in ei[0]] + [dist.get(int(b), 3) for b in ei[1]]
        ed.append(np.minimum(np.array(ds[:len(ds)//2]), np.array(ds[len(ds)//2:])).astype(np.float32))
    return ed  # list per edge type


def reg_explain(model, data, sub, local, gene_idx, pheno_idx, g_local, p_local,
                model_name="sage"):
    """ReGEX edge-mask optimisation on the subgraph."""
    xd = {nt: sub[nt].x for nt in data.node_types}
    counts, total = _edge_type_counts(sub)
    q_rel = _relation_prior(sub, counts, total)
    ed_lists = _edge_dist_to_seeds(sub, local, gene_idx, pheno_idx)
    maxd = max([e.max().item() for e in ed_lists]) + 1e-6 if ed_lists else 1.0

    logs = []
    etypes = list(sub.edge_types)
    for i, (s, r, d) in enumerate(etypes):
        n = sub[(s, r, d)].edge_index.shape[1]
        logs.append(torch.zeros(n, requires_grad=True))
    opt = torch.optim.Adam(logs, lr=C.MASK_LR)
    tau = C.GUMBEL_TAU

    s0 = score_pair(model, sub, g_local, p_local, data=data)  # full-subgraph prediction

    for step in range(C.MASK_STEPS):
        opt.zero_grad()
        # Gumbel-Sigmoid soft masks + hard (straight-through) masks
        soft = [gumbel_sigmoid(l, tau) for l in logs]
        hard = _hard_masks(soft)
        # forward with hard mask -> subgraph with kept edges only
        xd2 = xd
        eid2 = {}
        for i, (s, r, d) in enumerate(etypes):
            ei = sub[(s, r, d)].edge_index
            empty = torch.zeros(ei.shape[1], dtype=torch.bool)
            eid2[(s, r, d)] = ei[:, hard[i]] if hard[i].any() else ei[:, empty]
        with torch.no_grad():
            emb = model.encode(sub, xd2, eid2)
            s_m = (emb["gene"][g_local] * emb["phenotype"][p_local]).sum()
        # fidelity loss on hard prediction (straight-through grad via soft)
        loss = -s_m
        # sparsity: entropy of soft masks
        H = sum(F.binary_cross_entropy(m, torch.zeros_like(m), reduction="sum")
                for m in soft)
        loss = loss + C.LAMBDA_SPARSITY * (H / (total + 1e-6))
        # geometry: prefer edges close to the seeds
        g_geom = sum((m * torch.from_numpy(e_d / maxd)).sum()
                     for m, e_d in zip(soft, ed_lists))
        loss = loss + C.LAMBDA_GEOM * (g_geom / (total + 1e-6))
        # relation prior: KL(soft mask type dist || subgraph type dist)
        p_vals = []
        for i, (s, r, d) in enumerate(etypes):
            p_vals.append(soft[i].mean().item())
        pv = np.array(p_vals) + 1e-8
        pv = pv / pv.sum()
        kl = float((pv * np.log(pv / (q_rel + 1e-8))).sum())
        loss = loss + C.LAMBDA_REL * kl
        loss.backward()
        opt.step()

    soft_f, hard_f = _final_masks(logs, tau)
    # return soft edge weights aligned to sub.edge_types (continuous,
    # comparable with gradient-based baselines under top-K evaluation)
    weights = {}
    for i, (s, r, d) in enumerate(etypes):
        weights[(s, r, d)] = soft_f[i].detach().numpy()
    return weights, s0


# --------------------------------------------------------------------------
# baselines
# --------------------------------------------------------------------------
def mask_only_explain(model, data, sub, gene_idx, pheno_idx, g_local, p_local):
    """GNNExplainer-style ablation: fidelity + sparsity, no priors."""
    logs = []
    etypes = list(sub.edge_types)
    for (s, r, d) in etypes:
        n = sub[(s, r, d)].edge_index.shape[1]
        logs.append(torch.zeros(n, requires_grad=True))
    opt = torch.optim.Adam(logs, lr=C.MASK_LR)
    tau = C.GUMBEL_TAU
    xd = {nt: sub[nt].x for nt in data.node_types}
    s0 = score_pair(model, sub, g_local, p_local, data=data)
    for step in range(C.MASK_STEPS):
        opt.zero_grad()
        soft = [gumbel_sigmoid(l, tau) for l in logs]
        hard = _hard_masks(soft)
        eid2 = {}
        for i, (s, r, d) in enumerate(etypes):
            ei = sub[(s, r, d)].edge_index
            empty = torch.zeros(ei.shape[1], dtype=torch.bool)
            eid2[(s, r, d)] = ei[:, hard[i]] if hard[i].any() else ei[:, empty]
        with torch.no_grad():
            emb = model.encode(sub, xd, eid2)
            s_m = (emb["gene"][g_local] * emb["phenotype"][p_local]).sum()
        loss = -s_m + C.LAMBDA_SPARSITY * (
            sum(F.binary_cross_entropy(m, torch.zeros_like(m), reduction="sum")
                for m in soft) / (sum(v.edge_index.shape[1] for _, v in sub.edge_items()) + 1e-6))
        loss.backward()
        opt.step()
    soft_f, hard_f = _final_masks(logs, tau)
    weights = {}
    for i, (s, r, d) in enumerate(etypes):
        weights[(s, r, d)] = soft_f[i].detach().numpy()
    return weights, s0


def saliency_edge(model, data, sub, gene_idx, pheno_idx, g_local, p_local):
    """Input-gradient node saliency -> edge weights (mean of endpoint saliency)."""
    attrs = {}
    base = {nt: sub[nt].x for nt in data.node_types}
    for nt in data.node_types:
        if sub[nt].num_nodes == 0:
            continue
        x = sub[nt].x.detach().clone().requires_grad_(True)
        xd = {k: (v if k != nt else x) for k, v in base.items()}
        eid = {et: v.edge_index for et, v in sub.edge_items()}
        emb = model.encode(sub, xd, eid)
        s = (emb["gene"][g_local] * emb["phenotype"][p_local]).sum()
        grad = torch.autograd.grad(s, x, retain_graph=False)[0]
        attrs[nt] = grad.abs().sum(dim=1).detach().numpy()
        sub[nt].x = sub[nt].x.detach()
    weights = {}
    for (s, r, d), v in sub.edge_items():
        ei = v.edge_index.numpy()
        a = attrs[s][ei[0]] + attrs[d][ei[1]]
        weights[(s, r, d)] = a / (a.sum() + 1e-9)
    return weights, None


def ig_edge(model, data, sub, gene_idx, pheno_idx, g_local, p_local, steps=40):
    """Integrated gradients node attribution -> edge weights."""
    attrs = {}
    base = {nt: sub[nt].x for nt in data.node_types}
    for nt in data.node_types:
        if sub[nt].num_nodes == 0:
            continue
        x0 = sub[nt].x.detach()
        acc = torch.zeros_like(x0)
        eid = {et: v.edge_index for et, v in sub.edge_items()}
        for alpha in torch.linspace(0.0, 1.0, steps):
            xi = (alpha * x0).detach().requires_grad_(True)
            xd = {k: (v if k != nt else xi) for k, v in base.items()}
            emb = model.encode(sub, xd, eid)
            s = (emb["gene"][g_local] * emb["phenotype"][p_local]).sum()
            grad = torch.autograd.grad(s, xi, retain_graph=False)[0]
            acc += grad
        attrs[nt] = ((acc / steps) * x0).abs().sum(dim=1).detach().numpy()
        sub[nt].x = sub[nt].x.detach()
    weights = {}
    for (s, r, d), v in sub.edge_items():
        ei = v.edge_index.numpy()
        a = attrs[s][ei[0]] + attrs[d][ei[1]]
        weights[(s, r, d)] = a / (a.sum() + 1e-9)
    return weights, None


def random_edge(sub, rng=None):
    rng = rng or np.random.default_rng(1)
    weights = {}
    for (s, r, d), v in sub.edge_items():
        n = v.edge_index.shape[1]
        w = rng.random(n)
        weights[(s, r, d)] = w / (w.sum() + 1e-9)
    return weights, None
