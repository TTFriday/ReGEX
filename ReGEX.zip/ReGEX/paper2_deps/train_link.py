# -*- coding: utf-8 -*-
"""
train_link.py — train GNN baselines on the gene-phenotype link-prediction task.

Protocol
--------
* Positive edges : gene-twas-phenotype associations from AtMAD (FDR < 0.05).
* Split         : 70% train / 10% validation / 20% test (random edge split).
* Cold start    : an additional 20% of phenotypes are held out entirely and
                  all of their TWAS edges form the cold-start test set.
* Negatives     : gene-phenotype pairs absent from the TWAS table (1:1 ratio).
* Metrics       : AUC-ROC, AUC-PR on the test positives; AUC on cold-start.

Outputs per model & seed
------------------------
results/models/<model>_s<seed>.pt   : checkpoint + metrics
results/tables/link_prediction.csv  : aggregated performance table
"""
import os, sys, json, time
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C
from models import LinkPredictor, type_offsets
from sklearn.metrics import roc_auc_score, average_precision_score

torch.set_num_threads(os.cpu_count() or 4)


def sample_negatives(n, gene_n, pheno_n, exclude, rng):
    out, seen = [], set(exclude)
    while len(out) < n:
        g = int(rng.integers(0, gene_n)); p = int(rng.integers(0, pheno_n))
        if (g, p) not in seen:
            seen.add((g, p)); out.append((g, p))
    return torch.tensor(out, dtype=torch.long)


def fixed_negatives(splits, rng, gene_n, pheno_n):
    """Validation / test / cold-start negatives shared across models (exclude all true TWAS pairs)."""
    all_pos = np.concatenate([splits["train_pos"], splits["val_pos"],
                              splits["test_pos"], splits["cold_test_pos"]], axis=1)
    all_pos_set = set(map(tuple, all_pos.T.tolist()))
    va_neg = sample_negatives(len(splits["val_pos"][0]), gene_n, pheno_n, all_pos_set, rng)
    te_neg = torch.tensor(splits["neg_test"], dtype=torch.long).t()
    cold_neg = sample_negatives(len(splits["cold_test_pos"][0]), gene_n, pheno_n, all_pos_set, rng)
    return va_neg, te_neg, cold_neg


def evaluate_scores(pos, neg):
    y = torch.cat([torch.ones_like(pos), torch.zeros_like(neg)]).numpy()
    s = torch.cat([pos, neg]).numpy()
    return roc_auc_score(y, s), average_precision_score(y, s)


def evaluate(model, data, gene_idx, pheno_idx, neg_idx):
    model.eval()
    with torch.no_grad():
        emb = model.encode(data, {nt: data[nt].x for nt in data.node_types})
        pos = model.score_links(emb["gene"], emb["phenotype"], gene_idx, pheno_idx)
        neg = model.score_links(emb["gene"], emb["phenotype"], neg_idx[:, 0], neg_idx[:, 1])
    return evaluate_scores(pos, neg)


def mask_twas(data, splits):
    """Remove val/test/cold TWAS edges from the message-passing graph so that
    evaluation is inductive w.r.t. the target relation (standard link-prediction
    protocol). Only training TWAS edges remain in the graph."""
    tr = torch.tensor(splits["train_pos"], dtype=torch.long)
    data["gene", "twas", "phenotype"].edge_index = tr
    data["phenotype", "twas_rev", "gene"].edge_index = tr.flip(0)
    return data


def run_model(model_name, data, splits, seed, verbose=True, hidden=None, num_layers=None):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed); np.random.seed(seed)
    data = mask_twas(data, splits)
    hidden = hidden if hidden is not None else C.HIDDEN
    num_layers = num_layers if num_layers is not None else C.GNN_LAYERS

    gene_n = data["gene"].num_nodes
    pheno_n = data["phenotype"].num_nodes
    feats = {nt: data[nt].x.shape[1] for nt in data.node_types}
    metadata = (list(data.node_types), list(data.edge_types))

    model = LinkPredictor(
        feats, hidden, hidden, model_name=model_name,
        metadata=metadata,
        num_relations=len(data.edge_types),
        num_heads=2, dropout=C.DROPOUT, num_layers=num_layers)
    opt = torch.optim.Adam(model.parameters(), lr=C.LR)
    loss_fn = torch.nn.BCEWithLogitsLoss()

    tr_idx = torch.tensor(splits["train_pos"], dtype=torch.long).t()
    va_idx = torch.tensor(splits["val_pos"], dtype=torch.long).t()
    te_idx = torch.tensor(splits["test_pos"], dtype=torch.long).t()
    cold_idx = torch.tensor(splits["cold_test_pos"], dtype=torch.long).t()

    va_neg, te_neg, cold_neg = fixed_negatives(splits, rng, gene_n, pheno_n)
    all_pos_set = set(map(tuple, np.concatenate(
        [splits["train_pos"], splits["val_pos"], splits["test_pos"],
         splits["cold_test_pos"]], axis=1).T.tolist()))

    best_auc, best_ep, best_state, patience = 0.0, -1, None, 0
    t0 = time.time()
    for ep in range(1, C.MAX_EPOCHS + 1):
        model.train()
        opt.zero_grad()
        emb = model.encode(data, {nt: data[nt].x for nt in data.node_types})
        pos_logit = model.score_links(emb["gene"], emb["phenotype"], tr_idx[:, 0], tr_idx[:, 1])
        tr_neg = sample_negatives(len(tr_idx), gene_n, pheno_n, all_pos_set, rng)
        neg_logit = model.score_links(emb["gene"], emb["phenotype"], tr_neg[:, 0], tr_neg[:, 1])
        loss = loss_fn(torch.cat([pos_logit, neg_logit]),
                       torch.cat([torch.ones_like(pos_logit), torch.zeros_like(neg_logit)]))
        loss.backward(); opt.step()

        if ep % 5 == 0 or ep == 1:
            va_auc, va_ap = evaluate(model, data, va_idx[:, 0], va_idx[:, 1], va_neg)
            if va_auc > best_auc:
                best_auc, best_ep, patience = va_auc, ep, 0
                best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            else:
                patience += 1
            if verbose:
                print(f"      [{model_name}|s{seed}] ep {ep:02d} loss {loss.item():.4f} "
                      f"valAUC {va_auc:.4f} best {best_auc:.4f} ({time.time()-t0:.0f}s)", flush=True)
            if patience >= C.PATIENCE:
                break
    # restore best
    model.load_state_dict(best_state)
    test_auc, test_ap = evaluate(model, data, te_idx[:, 0], te_idx[:, 1], te_neg)
    cold_auc, cold_ap = evaluate(model, data, cold_idx[:, 0], cold_idx[:, 1], cold_neg)
    if verbose:
        print(f"    => {model_name}|s{seed}: testAUC {test_auc:.4f} AP {test_ap:.4f} "
              f"coldAUC {cold_auc:.4f} (best ep {best_ep})", flush=True)

    # save embeddings for downstream tasks
    model.eval()
    with torch.no_grad():
        emb = model.encode(data, {nt: data[nt].x for nt in data.node_types})
        out = {"gene_emb": emb["gene"], "pheno_emb": emb["phenotype"],
               "test_auc": test_auc, "test_ap": test_ap,
               "cold_auc": cold_auc, "cold_ap": cold_ap,
               "best_epoch": best_ep, "state": best_state}
        torch.save(out, os.path.join(C.MODELS_DIR, f"{model_name}_s{seed}.pt"))
    return {"model": model_name, "seed": seed, "test_auc": test_auc, "test_ap": test_ap,
            "cold_auc": cold_auc, "cold_ap": cold_ap, "best_epoch": best_ep}


def run_node2vec(data, splits, seed, verbose=True):
    """Non-GNN shallow graph-embedding baseline: DeepWalk/node2vec (p=q=1) on
    the homogeneous projection of the (TWAS-masked) graph, with the same
    dot-product scorer and the same inductive evaluation protocol as the GNN
    baselines."""
    from models import DeepWalkN2V
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed); np.random.seed(seed)
    data = mask_twas(data, splits)

    offs = type_offsets(data)
    eis = []
    for (src, rel, dst), v in data.edge_items():
        ei = v.edge_index
        eis.append(torch.stack([ei[0] + offs[src], ei[1] + offs[dst]]))
    edge_index = torch.cat(eis, dim=1)
    n_nodes = sum(data[nt].num_nodes for nt in data.node_types)
    gene_n = data["gene"].num_nodes
    pheno_n = data["phenotype"].num_nodes

    # CSR neighbourhood for vectorised random walks
    ei_np = edge_index.numpy()
    deg = np.bincount(ei_np[0], minlength=n_nodes)
    indptr = np.concatenate([[0], np.cumsum(deg)])
    order = np.argsort(ei_np[0], kind="stable")
    indices = ei_np[1][order].astype(np.int64)
    # drop self-loops (LD edges are snp-snp and already fine; keep as-is)

    model = DeepWalkN2V(n_nodes, C.HIDDEN, indptr, indices,
                        walk_length=C.N2V_WALK_LENGTH,
                        window=C.N2V_CONTEXT_SIZE // 2,
                        walks_per_node=C.N2V_WALKS_PER_NODE,
                        num_neg=C.N2V_NUM_NEGATIVE)
    opt = torch.optim.SparseAdam(model.parameters(), lr=C.N2V_LR)

    va_idx = torch.tensor(splits["val_pos"], dtype=torch.long).t()
    te_idx = torch.tensor(splits["test_pos"], dtype=torch.long).t()
    cold_idx = torch.tensor(splits["cold_test_pos"], dtype=torch.long).t()
    va_neg, te_neg, cold_neg = fixed_negatives(splits, rng, gene_n, pheno_n)

    n_walks = n_nodes * C.N2V_WALKS_PER_NODE
    batch = C.N2V_BATCH_SIZE
    t0 = time.time()
    for ep in range(1, C.N2V_EPOCHS + 1):
        model.train()
        walks = model.sample_walks(rng)
        centers, contexts = model.pairs_from_walks(walks)
        n_pairs = centers.shape[0]
        perm = rng.permutation(n_pairs)
        total, n_b = 0.0, 0
        for s in range(0, n_pairs, batch):
            e = min(s + batch, n_pairs)
            idx = perm[s:e]
            c = torch.from_numpy(centers[idx])
            ctx = torch.from_numpy(contexts[idx])
            neg = torch.randint(0, n_nodes, (len(idx), C.N2V_NUM_NEGATIVE),
                                dtype=torch.long)
            opt.zero_grad()
            loss = model.loss_batch(c, ctx, neg)
            loss.backward(); opt.step()
            total += float(loss.item()); n_b += 1
        if verbose:
            print(f"      [node2vec|s{seed}] ep {ep}/{C.N2V_EPOCHS} "
                  f"loss {total / max(n_b, 1):.4f} ({time.time() - t0:.0f}s)", flush=True)

    model.eval()
    with torch.no_grad():
        emb_all = model.emb.weight.detach()
    gene_emb = emb_all[offs["gene"]:offs["gene"] + gene_n]
    pheno_emb = emb_all[offs["phenotype"]:offs["phenotype"] + pheno_n]

    def score(g, p):
        return (gene_emb[g] * pheno_emb[p]).sum(dim=1)

    test_auc, test_ap = evaluate_scores(score(te_idx[:, 0], te_idx[:, 1]),
                                        score(te_neg[:, 0], te_neg[:, 1]))
    cold_auc, cold_ap = evaluate_scores(score(cold_idx[:, 0], cold_idx[:, 1]),
                                        score(cold_neg[:, 0], cold_neg[:, 1]))
    if verbose:
        print(f"    => node2vec|s{seed}: testAUC {test_auc:.4f} AP {test_ap:.4f} "
              f"coldAUC {cold_auc:.4f} ({time.time() - t0:.0f}s)", flush=True)

    out = {"gene_emb": gene_emb, "pheno_emb": pheno_emb,
           "test_auc": test_auc, "test_ap": test_ap,
           "cold_auc": cold_auc, "cold_ap": cold_ap,
           "best_epoch": C.N2V_EPOCHS, "state": None}
    torch.save(out, os.path.join(C.MODELS_DIR, f"node2vec_s{seed}.pt"))
    return {"model": "node2vec", "seed": seed, "test_auc": test_auc, "test_ap": test_ap,
            "cold_auc": cold_auc, "cold_ap": cold_ap, "best_epoch": C.N2V_EPOCHS}


def main():
    data = C.load_data()
    splits = C.load_splits()
    models = ["mlp", "gcn", "gat", "rgcn", "hgt", "sage", "node2vec"]
    rows = []
    for m in models:
        for s in C.SEEDS:
            if m == "node2vec":
                rows.append(run_node2vec(data, splits, s))
            else:
                rows.append(run_model(m, data, splits, s))
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(C.TABLES_DIR, "link_prediction.csv"), index=False)
    print("\n=== LINK PREDICTION SUMMARY ===")
    print(df.groupby("model")[["test_auc", "test_ap", "cold_auc", "cold_ap"]]
          .agg(["mean", "std"]).round(4).to_string())


if __name__ == "__main__":
    main()
