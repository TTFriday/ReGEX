# -*- coding: utf-8 -*-
"""
build_graph.py — construct the AtMAD multi-omics heterogeneous graph benchmark.

Node types : snp | gene | phenotype | pathway | cpg
Edge types : snp-eqtl-gene | snp-gwas-phenotype | gene-twas-phenotype (TARGET)
             pathway-pheno_path-phenotype | gene-emqtl-cpg | cpg-ewas-phenotype
             cpg-epathway-pathway | snp-ld-snp (GWAS-eQTL LD >= 0.8)

The epigenetic (CpG) layer is subsampled to the TOP_CPG_TOTAL CpG sites with the
highest combined association degree (emQTL + epathway + EWAS), a standard
tractability choice for benchmarks run on commodity hardware.

Outputs
-------
data/atmad_hetero.pt   : torch_geometric HeteroData (both directions per relation)
data/splits.pt         : train/val/test edge splits for TWAS link prediction
data/node_names.json   : node name lists (name <-> index mapping)
data/graph_stats.json  : node/edge statistics
"""
import os, sys, json, argparse
from collections import Counter
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import config as C

from torch_geometric.data import HeteroData

ap = argparse.ArgumentParser()
ap.add_argument("--cpg-total", type=int, default=C.TOP_CPG_TOTAL,
                help="number of CpG nodes kept by combined association degree")
ap.add_argument("--tag", type=str, default="",
                help="output suffix (e.g. 'cpg60k'); empty = canonical outputs")
args = ap.parse_args()
TOP_CPG_TOTAL = args.cpg_total
TAG = ("_" + args.tag) if args.tag else ""

R = C.RANDOM_SEED
rng = np.random.default_rng(R)
np.random.seed(R)
torch.manual_seed(R)

# relation list: (source node type, relation name, target node type)
RELS = [
    ("snp", "eqtl", "gene"),
    ("snp", "gwas", "phenotype"),
    ("gene", "twas", "phenotype"),
    ("pathway", "pheno_path", "phenotype"),
    ("gene", "emqtl", "cpg"),
    ("cpg", "ewas", "phenotype"),
    ("cpg", "epathway", "pathway"),
    ("snp", "ld", "snp"),
]


def norm_gene(s):
    return str(s).strip().upper()


def norm_snp(s):
    return str(s).strip()


def to_edges(src_series, dst_series, src_map, dst_map):
    src = src_series.map(src_map).values
    dst = dst_series.map(dst_map).values
    ok = ~(np.isnan(src) | np.isnan(dst))
    return np.stack([src[ok], dst[ok]], axis=0).astype(np.int64)


# --------------------------------------------------------------------------
# 1. Load raw association tables
# --------------------------------------------------------------------------
print("[1/7] Loading raw AtMAD tables ...", flush=True)
cis = pd.read_excel(os.path.join(C.RAW_DATA_DIR, "ciseqtl.xls"), engine="xlrd")
trans = pd.read_excel(os.path.join(C.RAW_DATA_DIR, "transeqtl.xls"), engine="xlrd")
gwas = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "gwas.csv"), encoding="utf-8")
twas = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "twas.csv"), encoding="utf-8-sig")
phenpath = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "phenotypepathway.csv"), encoding="latin-1")
emqtl = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "emqtl.csv"), encoding="utf-8-sig")
epathway = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "epathway.csv"), encoding="utf-8-sig")
gwaseqtl = pd.read_csv(os.path.join(C.RAW_DATA_DIR, "gwaseqtl.csv"), encoding="latin-1")

for df in (cis, trans):
    df["SNP"] = df["SNP"].map(norm_snp)
    df["Gene"] = df["Gene"].map(norm_gene)
gwas["SNP"] = gwas["SNP"].map(norm_snp)
gwas["Genename"] = gwas["Genename"].map(lambda s: norm_gene(s) if pd.notna(s) else np.nan)
twas["Gene"] = twas["Gene"].map(norm_gene)
emqtl["Gene"] = emqtl["Gene"].map(norm_gene)
gwaseqtl["eQTL loci"] = gwaseqtl["eQTL loci"].map(norm_snp)
gwaseqtl["GWAS loci"] = gwaseqtl["GWAS loci"].map(norm_snp)

# --------------------------------------------------------------------------
# 2. EWAS chunked pass: top-CpG subsampling
# --------------------------------------------------------------------------
print("[2/7] EWAS chunked pass ...", flush=True)
cpg_count = Counter()
chunksize = 500_000
for chunk in pd.read_csv(os.path.join(C.RAW_DATA_DIR, "ewas.csv"),
                         encoding="utf-8-sig", chunksize=chunksize,
                         usecols=["Methylation"]):
    for v in chunk["Methylation"].dropna().astype(str):
        cpg_count[v] += 1
top_ewas_cpgs = set(k for k, _ in cpg_count.most_common(C.TOP_CPGS))
print(f"    distinct CpG in EWAS: {len(cpg_count):,d}; top-by-EWAS: {len(top_ewas_cpgs):,d}", flush=True)

ewas_edges = []
for chunk in pd.read_csv(os.path.join(C.RAW_DATA_DIR, "ewas.csv"),
                         encoding="utf-8-sig", chunksize=chunksize,
                         usecols=["Phenotype", "Methylation"]):
    m = chunk["Methylation"].astype(str).isin(top_ewas_cpgs)
    if m.any():
        ewas_edges.append(chunk.loc[m, ["Phenotype", "Methylation"]])
ewas = pd.concat(ewas_edges, ignore_index=True) if ewas_edges else pd.DataFrame(columns=["Phenotype", "Methylation"])
if len(ewas) > C.MAX_EWAS_EDGES:
    ewas = ewas.sample(n=C.MAX_EWAS_EDGES, random_state=R)
print(f"    EWAS edges after subsampling: {len(ewas):,d}", flush=True)

# --------------------------------------------------------------------------
# 3. CpG node set: top by combined association degree
# --------------------------------------------------------------------------
print("[3/7] Selecting CpG nodes by combined degree ...", flush=True)
emqtl_cpg = emqtl.groupby("Methylation").size()
epath_cpg = epathway.groupby("Methylation").size()
ewas_cpg = ewas.groupby("Methylation").size()
combined = emqtl_cpg.add(epath_cpg, fill_value=0).add(ewas_cpg, fill_value=0)
top_cpgs = set(combined.nlargest(TOP_CPG_TOTAL).index)
cpg_ids = top_cpgs
print(f"    keeping top {len(top_cpgs):,d} CpG sites "
      f"(combined edges retained: emqtl={int(emqtl_cpg.reindex(top_cpgs, fill_value=0).sum()):,d}, "
      f"epathway={int(epath_cpg.reindex(top_cpgs, fill_value=0).sum()):,d}, "
      f"ewas={int(ewas_cpg.reindex(top_cpgs, fill_value=0).sum()):,d})", flush=True)

# --------------------------------------------------------------------------
# 4. Node id maps
# --------------------------------------------------------------------------
print("[4/7] Building node maps ...", flush=True)
snp_ids = set(gwas["SNP"]) | set(cis["SNP"]) | set(trans["SNP"])
gene_ids = set(twas["Gene"]) | set(cis["Gene"]) | set(trans["Gene"]) | set(emqtl["Gene"])
gene_ids |= set(gwas["Genename"].dropna())
pheno_ids = set(gwas["Phenotype"]) | set(twas["Phenotype"]) | set(phenpath["Phenotype"]) | set(ewas["Phenotype"])
pathway_ids = set(phenpath["Pathway"]) | set(epathway["Pathway"])

def build_map(ids):
    ids = sorted(ids)
    return {x: i for i, x in enumerate(ids)}, ids

snp_map, snp_list = build_map(snp_ids)
gene_map, gene_list = build_map(gene_ids)
pheno_map, pheno_list = build_map(pheno_ids)
pathway_map, pathway_list = build_map(pathway_ids)
cpg_map, cpg_list = build_map(cpg_ids)
print(f"    nodes -> snp={len(snp_list):,d} gene={len(gene_list):,d} "
      f"phenotype={len(pheno_list):,d} pathway={len(pathway_list):,d} cpg={len(cpg_list):,d}")
with open(os.path.join(C.DATA_DIR, f"node_names{TAG}.json"), "w", encoding="utf-8") as f:
    json.dump({"snp": snp_list, "gene": gene_list, "phenotype": pheno_list,
               "pathway": pathway_list, "cpg": cpg_list}, f, ensure_ascii=False)

# --------------------------------------------------------------------------
# 5. Edge lists
# --------------------------------------------------------------------------
print("[5/7] Building edges ...", flush=True)
edges = {}
edges["eqtl"] = np.concatenate([
    to_edges(cis["SNP"], cis["Gene"], snp_map, gene_map),
    to_edges(trans["SNP"], trans["Gene"], snp_map, gene_map)], axis=1)
edges["gwas"] = to_edges(gwas["SNP"], gwas["Phenotype"], snp_map, pheno_map)
edges["twas"] = to_edges(twas["Gene"], twas["Phenotype"], gene_map, pheno_map)
edges["pheno_path"] = to_edges(phenpath["Pathway"], phenpath["Phenotype"], pathway_map, pheno_map)
edges["emqtl"] = to_edges(emqtl["Gene"], emqtl["Methylation"], gene_map, cpg_map)
edges["ewas"] = to_edges(ewas["Methylation"], ewas["Phenotype"], cpg_map, pheno_map)
edges["epathway"] = to_edges(epathway["Methylation"], epathway["Pathway"], cpg_map, pathway_map)

ld = gwaseqtl[gwaseqtl["LD"] >= C.LD_THRESHOLD]
ld_src = ld["eQTL loci"].map(snp_map).values
ld_dst = ld["GWAS loci"].map(snp_map).values
ok = ~(np.isnan(ld_src) | np.isnan(ld_dst))
edges["ld"] = np.stack([ld_src[ok], ld_dst[ok]], axis=0).astype(np.int64)
print("    edge counts:", {k: int(v.shape[1]) for k, v in edges.items()}, flush=True)

# --------------------------------------------------------------------------
# 6. Node features
# --------------------------------------------------------------------------
print("[6/7] Building node features ...", flush=True)
def log1p_counts(series_counts, n_nodes):
    x = np.zeros(n_nodes)
    for idx, v in series_counts.items():
        if idx == idx and idx >= 0:
            x[int(idx)] = np.log1p(v)
    return x

# --- gene: [n_cis, n_trans, n_emqtl] (TWAS/GWAS counts excluded -> no target leakage)
gene_cis = cis.groupby("Gene").size()
gene_trans = trans.groupby("Gene").size()
gene_emqtl = emqtl[emqtl["Methylation"].isin(top_cpgs)].groupby("Gene").size()
def map_counts(grouped, id_map, n):
    """grouped: Series indexed by node name -> count; id_map: name -> index.
    (Series.map operates on values, so the name->index lookup must be done
    explicitly on the index to avoid silently producing all-zero features.)"""
    x = np.zeros(n)
    for name, v in grouped.items():
        if name in id_map:
            x[int(id_map[name])] = np.log1p(v)
    return x
gene_feat = np.stack([
    map_counts(gene_cis, gene_map, len(gene_list)),
    map_counts(gene_trans, gene_map, len(gene_list)),
    map_counts(gene_emqtl, gene_map, len(gene_list)),
], axis=1).astype(np.float32)

# --- phenotype: [ontology one-hot(24) + n_gwas + n_ewas]
pheno_ont = gwas.groupby("Phenotype")["Phenotype ontology"].agg(lambda s: s.dropna().iloc[0] if s.notna().any() else "NA")
top_onts = pheno_ont.value_counts().head(24).index.tolist()
ont_map = {o: i for i, o in enumerate(top_onts)}
pheno_gwas = gwas.groupby("Phenotype").size()
pheno_ewas = ewas.groupby("Phenotype").size()
pheno_feat = np.zeros((len(pheno_list), 24 + 2), dtype=np.float32)
for i, p in enumerate(pheno_list):
    o = pheno_ont.get(p, "NA")
    if o in ont_map:
        pheno_feat[i, ont_map[o]] = 1.0
    pheno_feat[i, 24] = np.log1p(pheno_gwas.get(p, 0))
    pheno_feat[i, 25] = np.log1p(pheno_ewas.get(p, 0))

# --- SNP: [MAF, impact one-hot(5), n_cis, n_trans, n_gwas]
maf = gwas.groupby("SNP")["MAF"].mean()
impacts = ["HIGH", "MODERATE", "LOW", "MODIFIER", "NA"]
imp_map = {x: i for i, x in enumerate(impacts)}
snp_cis = cis.groupby("SNP").size()
snp_trans = trans.groupby("SNP").size()
snp_gwas = gwas.groupby("SNP").size()
snp_imp = gwas.groupby("SNP")["Impact"].agg(lambda s: s.dropna().iloc[0] if s.notna().any() else "NA")
snp_feat = np.zeros((len(snp_list), 1 + 5 + 3), dtype=np.float32)
for i, s in enumerate(snp_list):
    snp_feat[i, 0] = float(maf.get(s, 0.0))
    imp = snp_imp.get(s, "NA")
    snp_feat[i, 1 + imp_map.get(imp, 4)] = 1.0
    snp_feat[i, 6] = np.log1p(snp_cis.get(s, 0))
    snp_feat[i, 7] = np.log1p(snp_trans.get(s, 0))
    snp_feat[i, 8] = np.log1p(snp_gwas.get(s, 0))

# --- pathway: [n_phenopath, n_epathway]
pw_pp = phenpath.groupby("Pathway").size()
pw_ep = epathway[epathway["Methylation"].isin(top_cpgs)].groupby("Pathway").size()
pathway_feat = np.stack([
    map_counts(pw_pp, pathway_map, len(pathway_list)),
    map_counts(pw_ep, pathway_map, len(pathway_list)),
], axis=1).astype(np.float32)

# --- CpG: [context one-hot(3), n_emqtl, n_ewas, n_epathway]
def ctx_of(s):
    p = str(s).split("_")
    return p[2] if len(p) == 3 else "UNKNOWN"
ctx_map = {"CG": 0, "CHG": 1, "CHH": 2}
cpg_feat = np.zeros((len(cpg_list), 3 + 3), dtype=np.float32)
for i, c in enumerate(cpg_list):
    ctx = ctx_of(c)
    if ctx in ctx_map:
        cpg_feat[i, ctx_map[ctx]] = 1.0
    cpg_feat[i, 3] = np.log1p(emqtl_cpg.get(c, 0))
    cpg_feat[i, 4] = np.log1p(ewas_cpg.get(c, 0))
    cpg_feat[i, 5] = np.log1p(epath_cpg.get(c, 0))

# --------------------------------------------------------------------------
# 7. Assemble HeteroData (both directions per relation)
# --------------------------------------------------------------------------
print("[7/7] Assembling HeteroData & splits ...", flush=True)
data = HeteroData()
for nt, f in [("snp", snp_feat), ("gene", gene_feat), ("phenotype", pheno_feat),
              ("pathway", pathway_feat), ("cpg", cpg_feat)]:
    data[nt].x = torch.tensor(f, dtype=torch.float32)
    data[nt].num_nodes = f.shape[0]
for (src, rel, dst) in RELS:
    e = torch.tensor(edges[rel], dtype=torch.long)
    data[src, rel, dst].edge_index = e
    data[dst, rel + "_rev", src].edge_index = e.flip(0)
n_dir_edges = sum(int(e.shape[1]) for e in data.edge_index_dict.values())
print(f"    HeteroData saved: {len(edges):d} relations, {n_dir_edges:,d} directed edges")
torch.save(data, os.path.join(C.DATA_DIR, f"atmad_hetero{TAG}.pt"))

# --- TWAS link-prediction splits ---
twas_ei = edges["twas"]
n_pos = twas_ei.shape[1]
idx = rng.permutation(n_pos)
n_val = int(n_pos * 0.1)
n_test = int(n_pos * C.LINK_TEST_RATIO)
val_idx, test_idx, train_idx = idx[:n_val], idx[n_val:n_val + n_test], idx[n_val + n_test:]

# negatives: gene-phenotype pairs absent from the COMPLETE TWAS table
neg_done = set(map(tuple, twas_ei.T.tolist()))
def sample_neg(n):
    out = []
    while len(out) < n:
        g = int(rng.integers(0, len(gene_list)))
        p = int(rng.integers(0, len(pheno_list)))
        if (g, p) not in neg_done:
            neg_done.add((g, p))
            out.append((g, p))
    return np.array(out, dtype=np.int64).T
neg_test = sample_neg(len(test_idx))

pheno_perm = rng.permutation(len(pheno_list))
n_cold = int(len(pheno_list) * C.COLD_PHENO_RATIO)
cold_phenos = set(pheno_perm[:n_cold].tolist())
cold_test_idx = np.where(np.isin(twas_ei[1], list(cold_phenos)))[0]

splits = {
    "train_pos": twas_ei[:, train_idx],
    "val_pos": twas_ei[:, val_idx],
    "test_pos": twas_ei[:, test_idx],
    "neg_test": neg_test,
    "cold_phenotypes": sorted(cold_phenos),
    "cold_test_pos": twas_ei[:, cold_test_idx],
}
torch.save(splits, os.path.join(C.DATA_DIR, f"splits{TAG}.pt"))

stats = {
    "n_nodes": {nt: len(lst) for nt, lst in [("snp", snp_list), ("gene", gene_list),
                                             ("phenotype", pheno_list), ("pathway", pathway_list),
                                             ("cpg", cpg_list)]},
    "n_edges": {k: int(v.shape[1]) for k, v in edges.items()},
    "twas_edges_total": int(n_pos),
    "train_pos": int(len(train_idx)), "val_pos": int(len(val_idx)),
    "test_pos": int(len(test_idx)), "cold_phenos": len(cold_phenos),
    "cold_test_pos": int(len(cold_test_idx)),
    "ontology_top24": top_onts,
}
with open(os.path.join(C.DATA_DIR, f"graph_stats{TAG}.json"), "w", encoding="utf-8") as f:
    json.dump(stats, f, ensure_ascii=False, indent=2)
print("DONE. stats:", json.dumps(stats, ensure_ascii=False)[:500])
