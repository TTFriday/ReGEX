# -*- coding: utf-8 -*-
"""
Shared configuration for the AtMAD heterogeneous graph benchmark (Paper 2).
Paths are relative to this directory; set ATMAD_RAW_DIR to the directory
that contains the original AtMAD association tables.
"""
import os

PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
RAW_DATA_DIR = os.environ.get("ATMAD_RAW_DIR", os.path.join(PROJECT_DIR, "rawdata"))
CODE_DIR = PROJECT_DIR
DATA_DIR = os.path.join(PROJECT_DIR, "data")
CURATED_DIR = os.path.join(DATA_DIR, "curated")
RESULTS_DIR = os.path.join(PROJECT_DIR, "results")
TABLES_DIR = os.path.join(RESULTS_DIR, "tables")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")
MODELS_DIR = os.path.join(RESULTS_DIR, "models")
PAPER_DIR = os.path.join(PROJECT_DIR, "paper")

for d in [DATA_DIR, CURATED_DIR, RESULTS_DIR, TABLES_DIR, FIGURES_DIR,
          MODELS_DIR, PAPER_DIR]:
    os.makedirs(d, exist_ok=True)

# --- data thresholds ---
LD_THRESHOLD = 0.8          # r2 threshold for GWAS-eQTL colocalisation edges
FDR_THRESHOLD = 0.05        # all AtMAD records are pre-filtered at this level
TOP_CPGS = 10000            # number of top EWAS CpG sites pre-selected
TOP_CPG_TOTAL = 30000       # CpG nodes kept by combined association degree
MAX_EWAS_EDGES = 400000     # cap on EWAS (CpG-phenotype) edges after CpG subsampling

# --- task splits ---
RANDOM_SEED = 42
LINK_TEST_RATIO = 0.2       # fraction of TWAS edges held out for link-prediction testing
COLD_PHENO_RATIO = 0.2      # fraction of phenotypes held out entirely (cold-start test)

# --- model hyper-parameters ---
HIDDEN = 32                 # hidden dimension (small enough for CPU training)
GNN_LAYERS = 2
DROPOUT = 0.3
LR = 1e-3
MAX_EPOCHS = 60
PATIENCE = 8                # early stopping
SEEDS = [42, 2024, 7, 2026, 123]   # random seeds for repeated runs
NEG_RATIO = 1               # one negative pair per positive edge in training

# --- node2vec (non-GNN graph-embedding baseline) ---
N2V_WALK_LENGTH = 12
N2V_CONTEXT_SIZE = 4          # skip-gram window = context_size // 2
N2V_WALKS_PER_NODE = 2
N2V_NUM_NEGATIVE = 5
N2V_EPOCHS = 3
N2V_BATCH_SIZE = 1024
N2V_LR = 0.01

# --- evaluation ---
TOP_K = [10, 50, 100]       # top-k for gene prioritisation recall


# --- loading helpers (PyTorch 2.6+ requires weights_only=False for PyG objects) ---
import torch as _torch

def load_data():
    return _torch.load(os.path.join(DATA_DIR, "atmad_hetero.pt"),
                       map_location="cpu", weights_only=False)

def load_splits():
    return _torch.load(os.path.join(DATA_DIR, "splits.pt"),
                       map_location="cpu", weights_only=False)
